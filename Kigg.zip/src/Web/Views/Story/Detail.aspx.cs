﻿namespace Kigg
{
    using System.Web.Mvc;

    public partial class StoryDetailView : ViewPage<BaseViewData>
    {
    }
}