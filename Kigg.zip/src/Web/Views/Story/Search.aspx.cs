﻿namespace Kigg
{
    using System.Web.Mvc;

    public partial class StoryListBySearchView : ViewPage<BaseViewData>
    {
    }
}
