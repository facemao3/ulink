﻿namespace Kigg
{
    using System.Web.Mvc;

    public partial class StoryListView : ViewUserControl<BaseStoryListData>
    {
    }
}