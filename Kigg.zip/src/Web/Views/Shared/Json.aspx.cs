﻿namespace Kigg
{
    using System.Web.Mvc;

    public partial class JsonView : ViewPage<JsonResult>
    {
    }
}
