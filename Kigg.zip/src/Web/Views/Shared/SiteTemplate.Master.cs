﻿namespace Kigg
{
    using System.Web.Mvc;

    public partial class SiteTemplate : ViewMasterPage<BaseViewData>
    {
    }
}