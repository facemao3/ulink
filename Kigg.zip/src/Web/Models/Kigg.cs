namespace Kigg
{
    partial class KiggDataContext
    {
    }
}
