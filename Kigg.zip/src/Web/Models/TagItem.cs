﻿namespace Kigg
{
    public class TagItem
    {
        public int ID
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public int Count
        {
            get;
            set;
        }
    }
}