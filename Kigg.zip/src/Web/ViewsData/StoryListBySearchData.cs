﻿namespace Kigg
{
    public class StoryListBySearchData : BaseStoryListData
    {
    }
}