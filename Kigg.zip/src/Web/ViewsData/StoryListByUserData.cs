﻿namespace Kigg
{
    public class StoryListByUserData : BaseStoryListData
    {
        public string PostedBy
        {
            get;
            set;
        }
    }
}