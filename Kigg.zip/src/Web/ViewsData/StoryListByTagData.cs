﻿namespace Kigg
{
    public class StoryListByTagData : BaseStoryListData
    {
        public string Tag
        {
            get;
            set;
        }
    }
}