﻿namespace Kigg
{
    public class StoryListByCategoryData : BaseStoryListData
    {
        public string Category
        {
            get;
            set;
        }
    }
}