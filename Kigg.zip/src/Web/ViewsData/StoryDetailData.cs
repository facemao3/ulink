﻿namespace Kigg
{
    public class StoryDetailData : BaseViewData
    {
        public StoryDetailItem Story
        {
            get;
            set;
        }
    }
}